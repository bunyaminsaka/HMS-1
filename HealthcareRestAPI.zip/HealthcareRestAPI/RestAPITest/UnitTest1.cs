using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using HealthcareRestAPI.Models;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using Newtonsoft.Json;
using Xunit;

public class HealthcareApiTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public HealthcareApiTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services =>
            {
                // Remove the existing context configuration
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<HealthcareContext>));
                if (descriptor != null)
                {
                    services.Remove(descriptor);
                }

                // Add an in-memory database for testing
                services.AddDbContext<HealthcareContext>(options =>
                {
                    options.UseInMemoryDatabase("InMemoryDbForTesting");
                });
            });
        });
    }

    [Fact]
    public async Task Get_EndpointsReturnSuccessAndCorrectContentType()
    {
        // Arrange
        var client = _factory.CreateClient();

        // Act
        var response = await client.GetAsync("/");

        // Assert
        response.EnsureSuccessStatusCode(); // Status Code 200-299
        Assert.Equal("application/json; charset=utf-8",
            response.Content.Headers.ContentType.ToString());
    }

    [Fact]
    public void Services_AreConfiguredCorrectly()
    {
        // Arrange
        var services = _factory.Services;

        // Act
        var dbContext = services.GetService(typeof(HealthcareContext));
        var jwtBearerOptions = services.GetService(typeof(JwtBearerOptions));

        // Assert
        Assert.NotNull(dbContext);
        Assert.NotNull(jwtBearerOptions);
    }

    [Fact]
    public async Task SwaggerUI_IsAvailableInDevelopment()
    {
        // Arrange
        var client = _factory.CreateClient();

        // Act
        var response = await client.GetAsync("/swagger");

        // Assert
        response.EnsureSuccessStatusCode(); // Status Code 200-299
        Assert.Contains("Swagger UI", await response.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Create_Read_Update_Delete_Entity()
    {
        // Arrange
        var client = _factory.CreateClient();
        var entity = new YourEntity { /* Initialize properties */ };
        var content = new StringContent(JsonConvert.SerializeObject(entity), Encoding.UTF8, "application/json");

        // Create
        var createResponse = await client.PostAsync("/api/yourentity", content);
        createResponse.EnsureSuccessStatusCode();

        // Read
        var readResponse = await client.GetAsync("/api/yourentity");
        readResponse.EnsureSuccessStatusCode();
        var readContent = await readResponse.Content.ReadAsStringAsync();
        var entities = JsonConvert.DeserializeObject<List<YourEntity>>(readContent);
        Assert.Contains(entities, e => e.Property == entity.Property);

        // Update
        entity.Property = "UpdatedValue";
        content = new StringContent(JsonConvert.SerializeObject(entity), Encoding.UTF8, "application/json");
        var updateResponse = await client.PutAsync($"/api/yourentity/{entity.Id}", content);
        updateResponse.EnsureSuccessStatusCode();

        // Read again to verify update
        readResponse = await client.GetAsync("/api/yourentity");
        readResponse.EnsureSuccessStatusCode();
        readContent = await readResponse.Content.ReadAsStringAsync();
        entities = JsonConvert.DeserializeObject<List<YourEntity>>(readContent);
        Assert.Contains(entities, e => e.Property == "UpdatedValue");

        // Delete
        var deleteResponse = await client.DeleteAsync($"/api/yourentity/{entity.Id}");
        deleteResponse.EnsureSuccessStatusCode();

        // Read again to verify delete
        readResponse = await client.GetAsync("/api/yourentity");
        readResponse.EnsureSuccessStatusCode();
        readContent = await readResponse.Content.ReadAsStringAsync();
        entities = JsonConvert.DeserializeObject<List<YourEntity>>(readContent);
        Assert.DoesNotContain(entities, e => e.Id == entity.Id);
    }
}
using System;
using System.ComponentModel.DataAnnotations;

public class MedicalRecord
{
    public int Id { get; set; }

    [Required]
    public int PatientId { get; set; }

    [Required]
    [StringLength(200)]
    public string Diagnosis { get; set; }

    [Required]
    [StringLength(200)]
    public string Treatment { get; set; }

    [Required]
    public DateTime RecordDate { get; set; }
}

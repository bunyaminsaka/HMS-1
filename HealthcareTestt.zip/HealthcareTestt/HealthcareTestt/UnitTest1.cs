using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using HealthcareRestAPI.Models;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Xunit;

public class HealthcareApiTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public HealthcareApiTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services =>
            {
                // Remove the existing context configuration
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<HealthcareContext>));
                if (descriptor != null)
                {
                    services.Remove(descriptor);
                }

                // Add an in-memory database for testing
                services.AddDbContext<HealthcareContext>(options =>
                {
                    options.UseInMemoryDatabase("InMemoryDbForTesting");
                });
            });
        });
    }

    [Fact]
    public async Task Get_EndpointsReturnSuccessAndCorrectContentType()
    {
        var client = _factory.CreateClient();
        var response = await client.GetAsync("/");

        response.EnsureSuccessStatusCode();
        Assert.Equal("application/json; charset=utf-8",
            response.Content.Headers.ContentType.ToString());
    }

    [Fact]
    public async Task Create_WithValidAndInvalidData()
    {
        var client = _factory.CreateClient();

        // Valid data
        var validEntity = new YourEntity { Property = "ValidValue" };
        var validContent = new StringContent(JsonConvert.SerializeObject(validEntity), Encoding.UTF8, "application/json");
        var validResponse = await client.PostAsync("/api/yourentity", validContent);
        validResponse.EnsureSuccessStatusCode();

        // Invalid data (missing required property)
        var invalidEntity = new YourEntity();
        var invalidContent = new StringContent(JsonConvert.SerializeObject(invalidEntity), Encoding.UTF8, "application/json");
        var invalidResponse = await client.PostAsync("/api/yourentity", invalidContent);
        Assert.Equal(System.Net.HttpStatusCode.BadRequest, invalidResponse.StatusCode);
    }

    [Fact]
    public async Task Read_WithFiltersAndSorting()
    {
        var client = _factory.CreateClient();

        // Arrange: Add entities
        var entity1 = new YourEntity { Property = "Value1" };
        var entity2 = new YourEntity { Property = "Value2" };
        await client.PostAsync("/api/yourentity", new StringContent(JsonConvert.SerializeObject(entity1), Encoding.UTF8, "application/json"));
        await client.PostAsync("/api/yourentity", new StringContent(JsonConvert.SerializeObject(entity2), Encoding.UTF8, "application/json"));

        // Act: Fetch with filter
        var filterResponse = await client.GetAsync("/api/yourentity?filter=Value1");
        filterResponse.EnsureSuccessStatusCode();
        var filterContent = await filterResponse.Content.ReadAsStringAsync();
        var filteredEntities = JsonConvert.DeserializeObject<List<YourEntity>>(filterContent);
        Assert.Single(filteredEntities);

        // Act: Fetch with sorting
        var sortResponse = await client.GetAsync("/api/yourentity?sort=asc");
        sortResponse.EnsureSuccessStatusCode();
        var sortContent = await sortResponse.Content.ReadAsStringAsync();
        var sortedEntities = JsonConvert.DeserializeObject<List<YourEntity>>(sortContent);
        Assert.Equal("Value1", sortedEntities.First().Property);
    }

    [Fact]
    public async Task Update_WithValidAndInvalidData()
    {
        var client = _factory.CreateClient();

        // Arrange: Create entity
        var entity = new YourEntity { Property = "InitialValue" };
        var content = new StringContent(JsonConvert.SerializeObject(entity), Encoding.UTF8, "application/json");
        var createResponse = await client.PostAsync("/api/yourentity", content);
        createResponse.EnsureSuccessStatusCode();
        var createdEntity = JsonConvert.DeserializeObject<YourEntity>(await createResponse.Content.ReadAsStringAsync());

        // Act: Update with valid data
        createdEntity.Property = "UpdatedValue";
        content = new StringContent(JsonConvert.SerializeObject(createdEntity), Encoding.UTF8, "application/json");
        var updateResponse = await client.PutAsync($"/api/yourentity/{createdEntity.Id}", content);
        updateResponse.EnsureSuccessStatusCode();

        // Act: Update with invalid data
        createdEntity.Property = null;
        content = new StringContent(JsonConvert.SerializeObject(createdEntity), Encoding.UTF8, "application/json");
        var invalidUpdateResponse = await client.PutAsync($"/api/yourentity/{createdEntity.Id}", content);
        Assert.Equal(System.Net.HttpStatusCode.BadRequest, invalidUpdateResponse.StatusCode);
    }

    [Fact]
    public async Task Delete_AndVerifyDeletion()
    {
        var client = _factory.CreateClient();

        // Arrange: Create entity
        var entity = new YourEntity { Property = "ToBeDeleted" };
        var content = new StringContent(JsonConvert.SerializeObject(entity), Encoding.UTF8, "application/json");
        var createResponse = await client.PostAsync("/api/yourentity", content);
        createResponse.EnsureSuccessStatusCode();
        var createdEntity = JsonConvert.DeserializeObject<YourEntity>(await createResponse.Content.ReadAsStringAsync());

        // Act: Delete the entity
        var deleteResponse = await client.DeleteAsync($"/api/yourentity/{createdEntity.Id}");
        deleteResponse.EnsureSuccessStatusCode();

        // Act: Verify deletion
        var readResponse = await client.GetAsync("/api/yourentity");
        readResponse.EnsureSuccessStatusCode();
        var readContent = await readResponse.Content.ReadAsStringAsync();
        var entities = JsonConvert.DeserializeObject<List<YourEntity>>(readContent);
        Assert.DoesNotContain(entities, e => e.Id == createdEntity.Id);
    }
}

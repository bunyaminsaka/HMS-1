// Models/DashboardViewModel.cs
public class DashboardViewModel
{
    public List<Admin> Admins { get; set; }
    public List<Doctor> Doctors { get; set; }
}

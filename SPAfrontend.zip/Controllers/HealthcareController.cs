﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HealthcareSystem.Controllers
{
    public class MainController : Controller
    {
        // Simulated in-memory data for Admin, Doctor, and entities
        private static List<Admin> Admins = new List<Admin>
        {
            new Admin { Id = 1, Name = "John Doe", Role = "Admin", CreatedAt = DateTime.Now }
        };

        private static List<Doctor> Doctors = new List<Doctor>
        {
            new Doctor { Id = 1, Name = "Dr. Jan Kowalski", Specialty = "Cardiology", ContactInfo = "123-456-789" }
        };

        // Admin Page
        public IActionResult AdminPanel()
        {
            return View("~/Views/Admin/AdminPanel.cshtml"); // Specify the path to the view
        }

        // Doctor Panel
        public IActionResult DoctorPanel(string pwz)
        {
            // Filter doctor data based on PWZ number
            var doctor = Doctors.FirstOrDefault(d => d.ContactInfo == pwz);
            if (doctor == null)
            {
                return NotFound(); // Return 404 if no doctor is found
            }
            return View(doctor); // Return doctor details to the view
        }

        // Back to Dashboard
        public IActionResult Index()
        {
            return View(); // Returns the dashboard view
        }
    }

    // Simulated Admin class
    public class Admin
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    // Simulated Doctor class
    public class Doctor
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Specialty { get; set; }
        public string ContactInfo { get; set; }
    }
}

﻿namespace HealthcareManagementSystem.Models
{
	public class Doctor
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string Specialty { get; set; }
        public int YearsOfExperience { get; set; } // Added property
        public ICollection<Appointment> Appointments { get; set; }
	}
}
